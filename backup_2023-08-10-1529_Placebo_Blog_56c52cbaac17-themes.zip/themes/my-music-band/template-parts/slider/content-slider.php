<?php
/**
 * The template for displaying featured posts on the front page
 *
 * @package My Music Band
 */
?>

<?php
my_music_band_featured_slider();
