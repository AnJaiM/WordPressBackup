<?php
/**
 * The template used for displaying credits
 *
 * @package My Music Band
 */
?>

<?php
/**
 * my_music_band_credits hook
 * @hooked my_music_band_footer_content - 10
 */
do_action( 'my_music_band_credits' );
